#!/usr/bin/env python3
"""
Pick 4/5 Prediction Tool - OPTIMIZED VERSION
=============================================

This version supports THREE database backends:
  1. sqlite   - Local SQLite databases
  2. mongo    - Original MongoDB (lotterypost collection)  
  3. mongo_v2 - Optimized MongoDB (lottery_v2 collection)

Toggle via URL: ?db=sqlite, ?db=mongo, or ?db=mongo_v2

PERFORMANCE COMPARISON:
=======================
Original Schema:
  - numbers stored as JSON string: "[\"3\", \"1\", \"8\", \"0\"]"
  - Must parse JSON for every document
  - No pre-calculated normalized/pairs fields
  - Queries require full table scans for pattern matching

Optimized Schema:
  - numbers as native array: ["3", "1", "8", "0"]
  - Pre-calculated: normalized, digits_sum, pairs_2dp, triples_3dp
  - Compound indexes on common query patterns
  - 10-50x faster for prediction algorithms
"""

from flask import Flask, render_template, jsonify, request
import os
import json
from datetime import datetime, timedelta
from collections import Counter
from itertools import combinations as iter_combinations
from pathlib import Path
import sqlite3
import hashlib

app = Flask(__name__)

# =============================================================================
# QUERY BILLING & COST ESTIMATION
# =============================================================================

QUERY_COST_CONFIG = {
    'efficacy_report': {
        'base_cost': 0.00,
        'per_seed_cost': 0.001,
        'threshold_seeds': 50,
        'threshold_time_seconds': 15,
    },
    'consecutive_draws': {
        'base_cost': 0.00,
        'per_state_cost': 0.01,
        'per_day_cost': 0.001,
        'threshold_states': 3,
        'threshold_days': 7,
        'threshold_time_seconds': 15,
    },
}

# In-memory job store (replace with Redis/Celery in production)
_background_jobs = {}

def estimate_query_cost(query_type, params):
    """Estimate the cost and time for a query."""
    if query_type == 'efficacy_report':
        return _estimate_efficacy_cost(params)
    elif query_type == 'consecutive_draws':
        return _estimate_consecutive_cost(params)
    return {'is_heavy': False, 'estimated_cost': 0, 'estimated_time_seconds': 5}

def _estimate_efficacy_cost(params):
    config = QUERY_COST_CONFIG['efficacy_report']
    start = datetime.strptime(params.get('start_date', '2026-01-01'), '%Y-%m-%d')
    end = datetime.strptime(params.get('end_date', '2026-01-15'), '%Y-%m-%d')
    days = (end - start).days + 1
    estimated_seeds = days * 2
    
    game_type = params.get('game_type', 'pick4')
    pair_size = params.get('pair_size', 2)
    candidate_estimates = {
        'pick2': {1: 10},
        'pick3': {1: 220, 2: 55},
        'pick4': {1: 715, 2: 330, 3: 120},
        'pick5': {1: 2002, 2: 715, 3: 252, 4: 126},
    }
    estimated_candidates = candidate_estimates.get(game_type, {}).get(pair_size, 500)
    estimated_time = (estimated_seeds * estimated_candidates * 0.0001) + 2
    
    cost = 0
    if estimated_seeds > config['threshold_seeds']:
        cost = (estimated_seeds - config['threshold_seeds']) * config['per_seed_cost']
    
    is_heavy = estimated_time > config['threshold_time_seconds']
    
    return {
        'estimated_seeds': estimated_seeds,
        'estimated_candidates': estimated_candidates,
        'estimated_time_seconds': round(estimated_time, 1),
        'estimated_cost': round(cost, 4),
        'is_heavy': is_heavy,
        'is_chargeable': cost > 0,
        'warnings': [f"~{int(estimated_time)}s query time"] if is_heavy else [],
        'recommendation': 'background' if is_heavy else 'immediate'
    }

def _estimate_consecutive_cost(params):
    config = QUERY_COST_CONFIG['consecutive_draws']
    start = datetime.strptime(params.get('start_date', '2026-01-01'), '%Y-%m-%d')
    end = datetime.strptime(params.get('end_date', '2026-01-01'), '%Y-%m-%d')
    days = (end - start).days + 1
    states = params.get('states', ['All'])
    num_states = 10 if 'All' in states else len(states)
    
    estimated_time = (num_states * days * 0.5) + 2
    
    cost = 0
    if num_states > config['threshold_states']:
        cost += (num_states - config['threshold_states']) * config['per_state_cost']
    if days > config['threshold_days']:
        cost += (days - config['threshold_days']) * config['per_day_cost']
    
    is_heavy = estimated_time > config['threshold_time_seconds']
    
    return {
        'num_states': num_states,
        'num_days': days,
        'estimated_time_seconds': round(estimated_time, 1),
        'estimated_cost': round(cost, 4),
        'is_heavy': is_heavy,
        'is_chargeable': cost > 0,
        'warnings': [f"~{int(estimated_time)}s query time"] if is_heavy else [],
        'recommendation': 'background' if is_heavy else 'immediate'
    }

def create_background_job(job_type, params, user_email):
    """Create a background job for heavy queries."""
    job_id = hashlib.md5(f"{job_type}{json.dumps(params, sort_keys=True, default=str)}{datetime.now().isoformat()}".encode()).hexdigest()[:12]
    _background_jobs[job_id] = {
        'id': job_id,
        'type': job_type,
        'params': params,
        'user_email': user_email,
        'status': 'queued',
        'created_at': datetime.now().isoformat(),
        'completed_at': None,
        'result': None,
        'error': None
    }
    return job_id

def get_job_status(job_id):
    return _background_jobs.get(job_id)

# =============================================================================
# CONFIGURATION
# =============================================================================

DEFAULT_DB_MODE = os.environ.get('DB_MODE', 'mongo_v2')  # sqlite, mongo, mongo_v2

# SQLite paths
PICK4_DB_PATH = Path(os.environ.get('PICK4_DB_PATH', '/Users/british.williams/lottery_scraper/pick4/data/pick4_master.db'))
PICK5_DB_PATH = Path(os.environ.get('PICK5_DB_PATH', '/Users/british.williams/lottery_scraper/pick5/data/pick5_data.db'))

# MongoDB
MONGO_URL = os.environ.get('MONGO_URL', '')
MONGO_DB = 'lottery'
MONGO_COLLECTION_ORIGINAL = 'lotterypost'        # Original schema
MONGO_COLLECTION_OPTIMIZED = 'lottery_v2'  # New optimized schema

# Lazy-loaded connections
_mongo_client = None

def get_mongo_client():
    global _mongo_client
    if _mongo_client is None:
        from pymongo import MongoClient
        _mongo_client = MongoClient(MONGO_URL)
    return _mongo_client


# =============================================================================
# DATABASE MODE HELPERS
# =============================================================================

def get_db_mode():
    """Get current database mode from request param or default."""
    return request.args.get('db', DEFAULT_DB_MODE).lower()

def get_collection():
    """Get the appropriate database collection based on mode."""
    mode = get_db_mode()
    
    if mode == 'sqlite':
        return SQLiteAdapter(PICK4_DB_PATH, PICK5_DB_PATH)
    elif mode == 'mongo_v2':
        client = get_mongo_client()
        return MongoOptimizedAdapter(client[MONGO_DB][MONGO_COLLECTION_OPTIMIZED])
    else:  # mongo (original)
        client = get_mongo_client()
        return MongoOriginalAdapter(client[MONGO_DB][MONGO_COLLECTION_ORIGINAL])


# =============================================================================
# MONGO OPTIMIZED ADAPTER (NEW SCHEMA)
# =============================================================================

class MongoOptimizedAdapter:
    """
    Adapter for optimized MongoDB schema.
    Takes advantage of pre-calculated fields for faster queries.
    """
    
    def __init__(self, collection):
        self.collection = collection
    
    def distinct(self, field, query=None):
        """Get distinct values."""
        # Map field names
        field_map = {'state_name': 'state_name', 'game_name': 'game_name', 'country': 'country'}
        mongo_field = field_map.get(field, field)
        return self.collection.distinct(mongo_field, query or {})
    
    def find(self, query, projection=None):
        """Find documents - returns cursor-like object."""
        # Transform query for optimized schema
        mongo_query = self._transform_query(query)
        cursor = self.collection.find(mongo_query, projection)
        return MongoOptimizedCursor(cursor)
    
    def find_one(self, query, sort=None):
        """Find single document."""
        mongo_query = self._transform_query(query)
        if sort:
            return self.collection.find_one(mongo_query, sort=sort)
        return self.collection.find_one(mongo_query)
    
    def find_by_normalized(self, normalized, state=None, game_type=None):
        """
        FAST: Find all draws matching a normalized pattern.
        Uses indexed 'normalized' field.
        """
        query = {'normalized': normalized.replace('-', '')}
        if state:
            query['state'] = self._state_name_to_code(state)
        if game_type:
            query['game_type'] = game_type
        return list(self.collection.find(query).sort('date', 1))
    
    def find_by_pairs(self, pairs, state=None, game_type='pick4'):
        """
        FAST: Find draws containing specific 2DP pairs.
        Uses indexed 'pairs_2dp' field.
        """
        query = {'pairs_2dp': {'$in': pairs}, 'game_type': game_type}
        if state:
            query['state'] = self._state_name_to_code(state)
        return list(self.collection.find(query).sort('date', 1))
    
    def _transform_query(self, query):
        """Transform query for optimized schema."""
        mongo_query = {}
        
        for key, value in query.items():
            if key == 'state_name':
                # Can query by state_name (full name) or state (code)
                mongo_query['state_name'] = value
            elif key == 'game_name':
                if isinstance(value, dict) and '$in' in value:
                    # Convert game names to game codes
                    mongo_query['game_name'] = {'$in': value['$in']}
                else:
                    mongo_query['game_name'] = value
            elif key == 'date':
                mongo_query['date'] = value
            elif key == '$or':
                mongo_query['$or'] = value
            else:
                mongo_query[key] = value
        
        return mongo_query
    
    def _state_name_to_code(self, name):
        """Convert state name to code."""
        mapping = {
            'california': 'ca', 'florida': 'fl', 'texas': 'tx', 'new york': 'ny',
            'washington dc': 'dc', 'georgia': 'ga', 'ohio': 'oh', 'pennsylvania': 'pa',
            'illinois': 'il', 'michigan': 'mi', 'new jersey': 'nj', 'virginia': 'va',
            'maryland': 'md', 'north carolina': 'nc', 'south carolina': 'sc',
            'tennessee': 'tn', 'kentucky': 'ky', 'indiana': 'in', 'missouri': 'mo',
            'wisconsin': 'wi', 'arkansas': 'ar', 'louisiana': 'la', 'iowa': 'ia',
            'connecticut': 'ct', 'delaware': 'de', 'west virginia': 'wv', 'oregon': 'or',
            'new mexico': 'nm', 'massachusetts': 'ma'
        }
        return mapping.get(name.lower(), name.lower())


class MongoOptimizedCursor:
    """Cursor wrapper for optimized MongoDB results."""
    
    def __init__(self, cursor):
        self.cursor = cursor
    
    def sort(self, field, direction=1):
        if isinstance(field, list):
            self.cursor = self.cursor.sort(field)
        else:
            self.cursor = self.cursor.sort(field, direction)
        return self
    
    def limit(self, n):
        self.cursor = self.cursor.limit(n)
        return self
    
    def __iter__(self):
        for doc in self.cursor:
            # Transform to common format expected by app
            yield {
                'country': doc.get('country', 'United States'),
                'state_name': doc.get('state_name', ''),
                'game_name': doc.get('game_name', ''),
                'date': doc.get('date'),
                'numbers': doc.get('numbers', '[]') if isinstance(doc.get('numbers'), str) else json.dumps(doc.get('numbers', [])),  # Keep as JSON string for compatibility
                'tod': doc.get('tod', ''),
                # Extra optimized fields available
                '_normalized': doc.get('normalized'),
                '_pairs_2dp': doc.get('pairs_2dp'),
                '_digits_sum': doc.get('digits_sum')
            }


# =============================================================================
# MONGO ORIGINAL ADAPTER
# =============================================================================

class MongoOriginalAdapter:
    """Adapter for original MongoDB schema (lotterypost collection)."""
    
    def __init__(self, collection):
        self.collection = collection
    
    def distinct(self, field, query=None):
        return self.collection.distinct(field, query or {})
    
    def find(self, query, projection=None):
        cursor = self.collection.find(query, projection)
        return MongoCursor(cursor)
    
    def find_one(self, query, sort=None):
        if sort:
            return self.collection.find_one(query, sort=sort)
        return self.collection.find_one(query)
    
    def aggregate(self, pipeline, allowDiskUse=False):
        return self.collection.aggregate(pipeline, allowDiskUse=allowDiskUse)


class MongoCursor:
    """Simple cursor wrapper."""
    
    def __init__(self, cursor):
        self.cursor = cursor
    
    def sort(self, field, direction=1):
        if isinstance(field, list):
            self.cursor = self.cursor.sort(field)
        else:
            self.cursor = self.cursor.sort(field, direction)
        return self
    
    def limit(self, n):
        self.cursor = self.cursor.limit(n)
        return self
    
    def __iter__(self):
        return iter(self.cursor)


# =============================================================================
# SQLITE ADAPTER (unchanged from previous version)
# =============================================================================

class SQLiteAdapter:
    """Adapter for SQLite databases."""
    
    def __init__(self, pick4_path, pick5_path):
        self.pick4_path = Path(pick4_path)
        self.pick5_path = Path(pick5_path)
    
    def _get_conn(self, game_type='pick4'):
        if game_type in ['pick5', 'fantasy5', 'cash5']:
            if self.pick5_path.exists():
                return sqlite3.connect(self.pick5_path)
            return None
        else:
            if self.pick4_path.exists():
                return sqlite3.connect(self.pick4_path)
            return None
    
    def _state_code_to_name(self, code):
        mapping = {
            'al': 'Alabama', 'ak': 'Alaska', 'az': 'Arizona', 'ar': 'Arkansas',
            'ca': 'California', 'co': 'Colorado', 'ct': 'Connecticut', 'de': 'Delaware',
            'dc': 'Washington DC', 'fl': 'Florida', 'ga': 'Georgia', 'hi': 'Hawaii',
            'id': 'Idaho', 'il': 'Illinois', 'in': 'Indiana', 'ia': 'Iowa',
            'ks': 'Kansas', 'ky': 'Kentucky', 'la': 'Louisiana', 'me': 'Maine',
            'md': 'Maryland', 'ma': 'Massachusetts', 'mi': 'Michigan', 'mn': 'Minnesota',
            'ms': 'Mississippi', 'mo': 'Missouri', 'mt': 'Montana', 'ne': 'Nebraska',
            'nv': 'Nevada', 'nh': 'New Hampshire', 'nj': 'New Jersey', 'nm': 'New Mexico',
            'ny': 'New York', 'nc': 'North Carolina', 'nd': 'North Dakota', 'oh': 'Ohio',
            'ok': 'Oklahoma', 'or': 'Oregon', 'pa': 'Pennsylvania', 'ri': 'Rhode Island',
            'sc': 'South Carolina', 'sd': 'South Dakota', 'tn': 'Tennessee', 'tx': 'Texas',
            'ut': 'Utah', 'vt': 'Vermont', 'va': 'Virginia', 'wa': 'Washington',
            'wv': 'West Virginia', 'wi': 'Wisconsin', 'wy': 'Wyoming'
        }
        return mapping.get(code.lower(), code.upper())
    
    def _state_name_to_code(self, name):
        mapping = {
            'alabama': 'al', 'alaska': 'ak', 'arizona': 'az', 'arkansas': 'ar',
            'california': 'ca', 'colorado': 'co', 'connecticut': 'ct', 'delaware': 'de',
            'washington dc': 'dc', 'florida': 'fl', 'georgia': 'ga', 'hawaii': 'hi',
            'idaho': 'id', 'illinois': 'il', 'indiana': 'in', 'iowa': 'ia',
            'kansas': 'ks', 'kentucky': 'ky', 'louisiana': 'la', 'maine': 'me',
            'maryland': 'md', 'massachusetts': 'ma', 'michigan': 'mi', 'minnesota': 'mn',
            'mississippi': 'ms', 'missouri': 'mo', 'montana': 'mt', 'nebraska': 'ne',
            'nevada': 'nv', 'new hampshire': 'nh', 'new jersey': 'nj', 'new mexico': 'nm',
            'new york': 'ny', 'north carolina': 'nc', 'north dakota': 'nd', 'ohio': 'oh',
            'oklahoma': 'ok', 'oregon': 'or', 'pennsylvania': 'pa', 'rhode island': 'ri',
            'south carolina': 'sc', 'south dakota': 'sd', 'tennessee': 'tn', 'texas': 'tx',
            'utah': 'ut', 'vermont': 'vt', 'virginia': 'va', 'washington': 'wa',
            'west virginia': 'wv', 'wisconsin': 'wi', 'wyoming': 'wy'
        }
        return mapping.get(name.lower(), name.lower())
    
    def _get_tod_from_game(self, game_name):
        game_lower = game_name.lower()
        if any(x in game_lower for x in ['evening', 'night', 'eve', 'pm', '10pm', '7pm']):
            return 'Evening'
        if any(x in game_lower for x in ['midday', 'mid-day', 'day', '1pm', '4pm']):
            return 'Midday'
        if 'morning' in game_lower:
            return 'Morning'
        return ''
    
    def distinct(self, field, query=None):
        results = set()
        for game_type in ['pick4', 'pick5']:
            conn = self._get_conn(game_type)
            if not conn:
                continue
            cursor = conn.cursor()
            table = 'pick4_results' if game_type == 'pick4' else 'pick5_results'
            try:
                if field == 'country':
                    results.add('United States')
                elif field == 'state_name':
                    cursor.execute(f'SELECT DISTINCT state FROM {table}')
                    for row in cursor.fetchall():
                        results.add(self._state_code_to_name(row[0]))
                elif field == 'game_name':
                    if query and 'state_name' in query:
                        state_code = self._state_name_to_code(query['state_name'])
                        cursor.execute(f'SELECT DISTINCT game FROM {table} WHERE state = ?', (state_code,))
                    else:
                        cursor.execute(f'SELECT DISTINCT game FROM {table}')
                    for row in cursor.fetchall():
                        # Convert 'daily-4' to 'Daily 4'
                        display_name = row[0].replace('-', ' ').title()
                        results.add(display_name)
            except Exception as e:
                print(f"SQLite distinct error ({game_type}): {e}")
            conn.close()
        return list(results)
    
    def find(self, query, projection=None):
        results = []
        game_types_to_check = ['pick4', 'pick5']
        
        if query.get('game_name'):
            game_names = []
            if isinstance(query['game_name'], dict) and '$in' in query['game_name']:
                game_names = query['game_name']['$in']
            elif isinstance(query['game_name'], str):
                game_names = [query['game_name']]
            
            for gn in game_names:
                gn_lower = gn.lower()
                if any(x in gn_lower for x in ['pick 5', 'pick5', 'daily 5']):
                    game_types_to_check = ['pick5']
                    break
                elif any(x in gn_lower for x in ['pick 4', 'pick4', 'daily 4', 'daily-4', 'dc-4', 'dc 4']):
                    game_types_to_check = ['pick4']
                    break
        
        for game_type in game_types_to_check:
            conn = self._get_conn(game_type)
            if not conn:
                continue
            cursor = conn.cursor()
            table = 'pick4_results' if game_type == 'pick4' else 'pick5_results'
            
            # Pick4 schema: id, state, game, draw_date, draw_time, num1, num2, num3, num4, bonus, created_at
            # Pick5 schema: id, state, game, draw_date, numbers, fireball, jackpot, created_at
            if game_type == 'pick4':
                sql = f'SELECT state, game, draw_date, draw_time, num1, num2, num3, num4 FROM {table} WHERE 1=1'
            else:
                sql = f'SELECT state, game, draw_date, numbers FROM {table} WHERE 1=1'
            params = []
            
            if 'state_name' in query:
                state_code = self._state_name_to_code(query['state_name'])
                sql += ' AND state = ?'
                params.append(state_code)
            
            if 'game_name' in query:
                if isinstance(query['game_name'], dict) and '$in' in query['game_name']:
                    game_codes = [self._normalize_game_name_to_db(gn) for gn in query['game_name']['$in']]
                    placeholders = ','.join(['?' for _ in game_codes])
                    sql += f' AND game IN ({placeholders})'
                    params.extend(game_codes)
                elif isinstance(query['game_name'], str):
                    sql += ' AND game = ?'
                    params.append(self._normalize_game_name_to_db(query['game_name']))
            
            if 'date' in query:
                if '$gte' in query['date']:
                    sql += ' AND draw_date >= ?'
                    d = query['date']['$gte']
                    params.append(d.strftime('%Y-%m-%d') if hasattr(d, 'strftime') else d)
                if '$lt' in query['date']:
                    sql += ' AND draw_date < ?'
                    d = query['date']['$lt']
                    params.append(d.strftime('%Y-%m-%d') if hasattr(d, 'strftime') else d)
            
            sql += ' ORDER BY draw_date ASC'
            
            try:
                cursor.execute(sql, params)
                for row in cursor.fetchall():
                    if game_type == 'pick4':
                        state_code, game, draw_date, draw_time, n1, n2, n3, n4 = row
                        nums = [str(n1), str(n2), str(n3), str(n4)]
                        tod = self._parse_draw_time(draw_time, game)
                    else:
                        state_code, game, draw_date, numbers_str = row
                        # Parse numbers - could be "1-2-3-4-5" or "12345" or similar
                        nums = self._parse_pick5_numbers(numbers_str)
                        tod = self._get_tod_from_game(game)
                    
                    if not nums or not all(n.isdigit() for n in nums):
                        continue
                    
                    results.append({
                        'country': 'United States',
                        'state_name': self._state_code_to_name(state_code),
                        'game_name': game.replace('-', ' ').title(),
                        'date': datetime.strptime(draw_date, '%Y-%m-%d'),
                        'numbers': json.dumps(nums),
                        'tod': tod
                    })
            except Exception as e:
                print(f"SQLite find error ({game_type}): {e}")
                import traceback
                traceback.print_exc()
            conn.close()
        
        return SQLiteCursor(results)
    
    def _normalize_game_name_to_db(self, name):
        """Convert display name to database format: 'Daily 4' -> 'daily-4'"""
        return name.lower().replace(' ', '-')
    
    def _parse_draw_time(self, draw_time, game_name):
        """Parse draw_time field or infer from game name."""
        if draw_time:
            dt_lower = str(draw_time).lower()
            if any(x in dt_lower for x in ['evening', 'night', 'pm', 'eve']):
                return 'Evening'
            if any(x in dt_lower for x in ['midday', 'mid', 'day', 'am']):
                return 'Midday'
            if 'morning' in dt_lower:
                return 'Morning'
        return self._get_tod_from_game(game_name)
    
    def _parse_pick5_numbers(self, numbers_str):
        """Parse Pick 5 numbers from various formats."""
        if not numbers_str:
            return []
        s = str(numbers_str).strip()
        # Try hyphen-separated: "1-2-3-4-5"
        if '-' in s:
            parts = s.split('-')
            if len(parts) == 5:
                return [p.strip() for p in parts]
        # Try space-separated: "1 2 3 4 5"
        if ' ' in s:
            parts = s.split()
            if len(parts) == 5:
                return parts
        # Try comma-separated: "1,2,3,4,5"
        if ',' in s:
            parts = s.split(',')
            if len(parts) == 5:
                return [p.strip() for p in parts]
        # Try plain digits: "12345"
        if s.isdigit() and len(s) == 5:
            return list(s)
        return []
    
    def find_one(self, query, sort=None):
        results = list(self.find(query))
        if sort:
            field, direction = sort[0] if isinstance(sort, list) else sort
            results.sort(key=lambda x: x.get(field, ''), reverse=(direction == -1))
        return results[0] if results else None


class SQLiteCursor:
    def __init__(self, results):
        self.results = results
        self._sort_field = None
        self._sort_dir = 1
        self._limit_val = None
    
    def sort(self, field, direction=1):
        if isinstance(field, str):
            self._sort_field = field
            self._sort_dir = direction
        elif isinstance(field, list):
            self._sort_field = field[0][0]
            self._sort_dir = field[0][1]
        return self
    
    def limit(self, n):
        self._limit_val = n
        return self
    
    def __iter__(self):
        results = self.results
        if self._sort_field:
            results = sorted(results, key=lambda x: x.get(self._sort_field, ''), 
                           reverse=(self._sort_dir == -1))
        if self._limit_val:
            results = results[:self._limit_val]
        return iter(results)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def parse_numbers(numbers_str):
    try:
        nums = json.loads(numbers_str)
        return [str(n) for n in nums]
    except:
        return []

def get_sorted_value(nums):
    if not nums:
        return ''
    try:
        return '-'.join(sorted(nums, key=lambda x: int(x)))
    except:
        return '-'.join(sorted(nums))

def get_2dp_pairs_pred(number):
    digits = list(str(number).replace('-', ''))
    pairs = []
    for combo in iter_combinations(digits, 2):
        pair = ''.join(sorted(combo, key=lambda x: int(x)))
        if pair not in pairs:
            pairs.append(pair)
    return sorted(pairs)

def generate_2dp_ap_candidates(pairs, num_digits=4):
    seen_normalized = set()
    candidates = []
    max_num = 10 ** num_digits
    for num in range(max_num):
        num_str = str(num).zfill(num_digits)
        norm = get_sorted_value(list(num_str))
        if norm in seen_normalized:
            continue
        digits_in_num = set(num_str)
        for pair in pairs:
            d1, d2 = pair[0], pair[1]
            if d1 in digits_in_num and d2 in digits_in_num:
                seen_normalized.add(norm)
                candidates.append(num_str)
                break
    return sorted(candidates)

def get_3dp_pairs_pred(number):
    digits = list(str(number).replace('-', ''))
    pairs = []
    for combo in iter_combinations(digits, 3):
        pair = ''.join(sorted(combo, key=lambda x: int(x)))
        if pair not in pairs:
            pairs.append(pair)
    return sorted(pairs)

def generate_3dp_ap_candidates(pairs, num_digits=5):
    seen_normalized = set()
    candidates = []
    max_num = 10 ** num_digits
    for num in range(max_num):
        num_str = str(num).zfill(num_digits)
        norm = get_sorted_value(list(num_str))
        if norm in seen_normalized:
            continue
        digits_in_num = list(num_str)
        for pair in pairs:
            d1, d2, d3 = pair[0], pair[1], pair[2]
            temp_digits = digits_in_num.copy()
            found = True
            for d in [d1, d2, d3]:
                if d in temp_digits:
                    temp_digits.remove(d)
                else:
                    found = False
                    break
            if found:
                seen_normalized.add(norm)
                candidates.append(num_str)
                break
    return sorted(candidates)


# =============================================================================
# UNIFIED DP FUNCTIONS (Supports any pair size: 1DP, 2DP, 3DP, 4DP)
# =============================================================================

def get_dp_pairs(number, pair_size):
    """
    Extract all unique digit pairs of given size from a number.
    
    Args:
        number: String or list of digits (e.g., "1234" or ["1","2","3","4"])
        pair_size: Size of pairs to extract (1, 2, 3, or 4)
    
    Returns:
        List of sorted digit pairs as strings
    """
    if isinstance(number, (list, tuple)):
        digits = [str(d) for d in number]
    else:
        digits = list(str(number).replace('-', '').replace(' ', ''))
    
    pairs = []
    for combo in iter_combinations(digits, pair_size):
        # Sort digits within pair for normalization
        pair = ''.join(sorted(combo, key=lambda x: int(x)))
        if pair not in pairs:
            pairs.append(pair)
    
    return sorted(pairs)


def number_contains_pair(number_digits, pair):
    """
    Check if a number contains all digits of a pair (with multiplicity).
    """
    temp_digits = list(number_digits)
    for d in pair:
        if d in temp_digits:
            temp_digits.remove(d)
        else:
            return False
    return True


def generate_dp_candidates(pairs, num_digits):
    """
    Generate all possible numbers that contain at least one of the given pairs.
    Works for any pair size (1DP, 2DP, 3DP, 4DP).
    
    Args:
        pairs: List of digit pairs to match
        num_digits: Number of digits in target numbers (3, 4, or 5)
    
    Returns:
        List of candidate numbers (normalized, no duplicates)
    """
    if not pairs:
        return []
    
    seen_normalized = set()
    candidates = []
    max_num = 10 ** num_digits
    
    for num in range(max_num):
        num_str = str(num).zfill(num_digits)
        norm = get_sorted_value(list(num_str))
        
        if norm in seen_normalized:
            continue
        
        digits_list = list(num_str)
        
        for pair in pairs:
            if number_contains_pair(digits_list, pair):
                seen_normalized.add(norm)
                candidates.append(num_str)
                break
    
    return sorted(candidates)

def get_games_for_prediction(state, game_type):
    collection = get_collection()
    all_games = collection.distinct('game_name', {'state_name': state})
    patterns = {
        # Pick 2 games
        'pick2': ['pick 2', 'pick2', 'pick-2', 'daily 2', 'daily2', 'play 2', 'play2', 'dc 2', 'dc2', 'cash 2', 'cash2'],
        # Pick 3 games
        'daily3': ['daily 3', 'daily3', 'daily-3', 'pick 3', 'pick3', 'pick-3', 'dc-3', 'dc 3', 'dc3', 'cash 3', 'cash-3', 'cash3', 'play 3', 'play-3', 'play3'],
        'pick3': ['pick 3', 'pick3', 'pick-3', 'daily 3', 'daily3', 'daily-3', 'dc-3', 'dc 3', 'dc3', 'cash 3', 'cash-3', 'cash3', 'play 3', 'play-3', 'play3'],
        # Pick 4 games
        'daily4': ['daily 4', 'daily4', 'daily-4', 'pick 4', 'pick4', 'pick-4', 'dc-4', 'dc 4', 'dc4', 'cash 4', 'cash-4', 'cash4', 'win 4', 'win-4', 'win4', 'play 4', 'play-4', 'play4'],
        'pick4': ['pick 4', 'pick4', 'pick-4', 'daily 4', 'daily4', 'daily-4', 'dc-4', 'dc 4', 'dc4', 'cash 4', 'cash-4', 'cash4', 'win 4', 'win-4', 'win4', 'play 4', 'play-4', 'play4'],
        # Pick 5 games
        'pick5': [
            # Pennsylvania - use specific TOD variants
            'pick 5 day', 'pick 5 evening', 'pick 5 midday',
            # Delaware - use specific TOD variants only
            'play 5 day', 'play 5 night',
            # Washington DC
            'dc 5 evening', 'dc 5 midday',
            # Georgia
            'georgia five evening', 'georgia five midday',
            # Generic fallbacks (only if no TOD variants exist)
            'pick 5', 'pick5',
            'daily 5', 'daily5',
            'cash 5', 'cash5',
            'dc 5', 'dc5',
            'play 5', 'play5',
            'georgia five', 'georgia 5',
        ],
        'fantasy5': ['fantasy 5', 'fantasy5', 'fantasy-5'],
    }
    pats = patterns.get(game_type.lower(), [game_type.lower()])
    matched = [g for g in all_games if any(p in g.lower() for p in pats)]
    
    # Remove parent games if child TOD variants exist (e.g., remove "Play 5" if "Play 5 Day" exists)
    filtered = []
    for game in matched:
        game_lower = game.lower()
        # Check if this is a parent game (no day/night/midday/evening suffix)
        is_parent = not any(tod in game_lower for tod in ['day', 'night', 'midday', 'evening'])
        if is_parent:
            # Check if any child variant exists
            has_child = any(
                g.lower().startswith(game_lower) and g.lower() != game_lower 
                for g in matched
            )
            if has_child:
                continue  # Skip parent, use children instead
        filtered.append(game)
    
    return filtered if filtered else matched


# =============================================================================
# ROUTES
# =============================================================================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/db-status')
def db_status():
    """Check database status."""
    mode = get_db_mode()
    status = {
        'mode': mode,
        'available_modes': ['sqlite', 'mongo', 'mongo_v2'],
        'toggle_hint': '?db=sqlite, ?db=mongo, or ?db=mongo_v2'
    }
    
    if mode == 'sqlite':
        status['pick4_path'] = str(PICK4_DB_PATH)
        status['pick5_path'] = str(PICK5_DB_PATH)
        status['pick4_exists'] = PICK4_DB_PATH.exists()
        status['pick5_exists'] = PICK5_DB_PATH.exists()
        
        for db_name, db_path, table in [('pick4', PICK4_DB_PATH, 'pick4_results'), ('pick5', PICK5_DB_PATH, 'pick5_results')]:
            if db_path.exists():
                try:
                    conn = sqlite3.connect(db_path)
                    cursor = conn.cursor()
                    cursor.execute(f'SELECT COUNT(*) FROM {table}')
                    status[f'{db_name}_records'] = cursor.fetchone()[0]
                    cursor.execute(f'SELECT MIN(draw_date), MAX(draw_date) FROM {table}')
                    row = cursor.fetchone()
                    status[f'{db_name}_date_range'] = f"{row[0]} to {row[1]}"
                    conn.close()
                except Exception as e:
                    status[f'{db_name}_error'] = str(e)
    
    elif mode in ['mongo', 'mongo_v2']:
        collection_name = MONGO_COLLECTION_OPTIMIZED if mode == 'mongo_v2' else MONGO_COLLECTION_ORIGINAL
        status['collection'] = collection_name
        status['schema'] = 'optimized' if mode == 'mongo_v2' else 'original'
        
        try:
            client = get_mongo_client()
            coll = client[MONGO_DB][collection_name]
            status['records'] = coll.count_documents({})
            status['states'] = len(coll.distinct('state_name' if mode == 'mongo' else 'state'))
            
            # Get date range
            pipeline = [{'$group': {'_id': None, 'min': {'$min': '$date'}, 'max': {'$max': '$date'}}}]
            result = list(coll.aggregate(pipeline))
            if result:
                status['date_range'] = f"{result[0]['min'].strftime('%Y-%m-%d')} to {result[0]['max'].strftime('%Y-%m-%d')}"
        except Exception as e:
            status['error'] = str(e)
    
    return jsonify(status)


# =============================================================================
# QUERY TOOL ENDPOINTS (for index.html)
# =============================================================================

@app.route('/api/countries')
def get_countries():
    """Get list of countries."""
    collection = get_collection()
    countries = collection.distinct('country')
    countries = sorted([c for c in countries if c])
    return jsonify([{'id': c, 'name': c} for c in countries])

@app.route('/api/states/<country>')
def get_states(country):
    """Get states for a country."""
    collection = get_collection()
    if country == 'all':
        states = collection.distinct('state_name')
    else:
        states = collection.distinct('state_name', {'country': country})
    states = sorted([s for s in states if s])
    return jsonify([{'id': s, 'name': s} for s in states])

@app.route('/api/games/<state>')
def get_games(state):
    """Get games for a state."""
    collection = get_collection()
    games = collection.distinct('game_name', {'state_name': state})
    games = sorted([g for g in games if g])
    return jsonify([{'id': g, 'name': g} for g in games])

@app.route('/api/lookup', methods=['POST'])
def lookup_number():
    """Look up a number in the database."""
    collection = get_collection()
    data = request.json
    
    number = data.get('number', '').replace('-', '').replace(' ', '')
    state = data.get('state', '')
    game = data.get('game', '')
    
    if not number:
        return jsonify({'error': 'Number is required'}), 400
    
    # Build query
    query = {}
    if state:
        query['state_name'] = state
    if game:
        query['game_name'] = game
    
    # Get all matching draws
    draws = list(collection.find(query))
    
    # Filter by number (check if normalized matches)
    num_digits = len(number)
    search_normalized = get_sorted_value(list(number))
    
    results = []
    for d in draws:
        nums = parse_numbers(d.get('numbers', '[]'))
        if len(nums) != num_digits:
            continue
        draw_normalized = get_sorted_value(nums)
        if draw_normalized == search_normalized:
            results.append({
                'date': d['date'].strftime('%Y-%m-%d'),
                'state': d.get('state_name', ''),
                'game': d.get('game_name', ''),
                'value': '-'.join(nums),
                'normalized': draw_normalized,
                'tod': d.get('tod', '')
            })
    
    # Sort by date descending
    results.sort(key=lambda x: x['date'], reverse=True)
    
    return jsonify({
        'search_number': number,
        'search_normalized': search_normalized,
        'total_hits': len(results),
        'results': results[:100],  # Limit to 100 results
        'db_mode': get_db_mode()
    })


@app.route('/api/prediction/states')
def get_prediction_states():
    collection = get_collection()
    states = collection.distinct('state_name')
    return jsonify(sorted([s for s in states if s]))

@app.route('/api/prediction/games/<state>')
def get_prediction_games(state):
    collection = get_collection()
    games = collection.distinct('game_name', {'state_name': state})
    game_types = set()
    for g in games:
        gl = g.lower()
        if any(x in gl for x in ['daily 3', 'daily3', 'pick 3', 'pick3', 'dc-3', 'dc 3']): 
            game_types.add('daily3')
        if any(x in gl for x in ['daily 4', 'daily4', 'pick 4', 'pick4', 'dc-4', 'dc 4', 'cash 4', 'win 4']): 
            game_types.add('daily4')
        if any(x in gl for x in ['pick 5', 'pick5', 'daily 5']): 
            game_types.add('pick5')
        if any(x in gl for x in ['fantasy 5', 'fantasy5', 'cash 5', 'cash5']): 
            game_types.add('fantasy5')
    type_labels = {
        'daily3': 'Daily 3 / Pick 3', 
        'daily4': 'Daily 4 / Pick 4', 
        'pick5': 'Pick 5 / Daily 5', 
        'fantasy5': 'Fantasy 5 / Cash 5'
    }
    return jsonify([{'id': t, 'name': type_labels.get(t, t)} for t in sorted(game_types)])

@app.route('/api/prediction/latest/<state>/<game_type>')
def get_latest_draw(state, game_type):
    collection = get_collection()
    games = get_games_for_prediction(state, game_type)
    if not games:
        return jsonify({'error': 'No games found', 'db_mode': get_db_mode()}), 404
    
    query = {'state_name': state, 'game_name': {'$in': games}}
    latest = collection.find_one(query, sort=[('date', -1)])
    
    if latest:
        nums = parse_numbers(latest.get('numbers', '[]'))
        return jsonify({
            'date': latest['date'].strftime('%Y-%m-%d'),
            'value': '-'.join(nums),
            'normalized': get_sorted_value(nums),
            'game': latest['game_name'],
            'tod': latest.get('tod', ''),
            'db_mode': get_db_mode()
        })
    return jsonify({'error': 'No draws found', 'db_mode': get_db_mode()}), 404


@app.route('/api/prediction/draw-by-date/<state>/<game_type>/<draw_date>')
def get_draw_by_date(state, game_type, draw_date):
    """Get draw for a specific date."""
    collection = get_collection()
    games = get_games_for_prediction(state, game_type)
    if not games:
        return jsonify({'error': 'No games found', 'db_mode': get_db_mode()}), 404
    
    try:
        date_obj = datetime.strptime(draw_date, '%Y-%m-%d')
    except:
        return jsonify({'error': 'Invalid date format'}), 400
    
    # Query for draws on this specific date
    query = {
        'state_name': state,
        'game_name': {'$in': games},
        'date': {'$gte': date_obj, '$lt': date_obj + timedelta(days=1)}
    }
    
    # Check for TOD filter
    tod = request.args.get('tod', '')
    
    # Find all draws for this date
    draws = list(collection.find(query))
    
    if not draws:
        return jsonify({'error': f'No draw found for {draw_date}', 'db_mode': get_db_mode()}), 404
    
    # Filter by TOD if specified
    if tod:
        filtered = [d for d in draws if d.get('tod', '').lower() == tod.lower()]
        if filtered:
            draws = filtered
    
    # Return the first matching draw (or most recent if multiple)
    draw = draws[0]
    nums = parse_numbers(draw.get('numbers', '[]'))
    
    return jsonify({
        'date': draw['date'].strftime('%Y-%m-%d'),
        'value': '-'.join(nums),
        'normalized': get_sorted_value(nums),
        'game': draw['game_name'],
        'tod': draw.get('tod', ''),
        'db_mode': get_db_mode()
    })


@app.route('/api/prediction/2dp-ap', methods=['POST'])
def predict_2dp_ap():
    """2DP-AP Prediction for Pick 4."""
    collection = get_collection()
    data = request.json
    seed_number = data.get('seed_number', data.get('seed', '')).replace('"', '').replace('[', '').replace(']', '').replace('-', '').replace(' ', '')
    seed_date_str = data.get('seed_date')
    state = data.get('state', 'California')
    game_type = data.get('game_type', 'daily4')
    days_threshold = int(data.get('days_threshold', 30))
    
    if not seed_number or not seed_date_str:
        return jsonify({'error': 'seed_number and seed_date required'}), 400
    
    num_digits = len(seed_number)
    seed_date = datetime.strptime(seed_date_str, '%Y-%m-%d')
    normalized_seed = get_sorted_value(list(seed_number))
    
    pairs_2dp = get_2dp_pairs_pred(normalized_seed.replace('-', ''))
    candidates = generate_2dp_ap_candidates(pairs_2dp, num_digits)
    
    games = get_games_for_prediction(state, game_type)
    if not games:
        return jsonify({'error': f'No {game_type} games found for {state}', 'db_mode': get_db_mode()}), 404
    
    query = {'state_name': state, 'game_name': {'$in': games}}
    all_draws = list(collection.find(query).sort('date', 1))
    
    seed_hits = []
    all_draws_lookup = {}
    
    for d in all_draws:
        nums = parse_numbers(d.get('numbers', '[]'))
        if len(nums) == num_digits:
            norm = get_sorted_value(nums)
            norm_key = norm.replace('-', '')
            if norm_key not in all_draws_lookup:
                all_draws_lookup[norm_key] = []
            all_draws_lookup[norm_key].append({
                'date': d['date'], 
                'value': '-'.join(nums), 
                'tod': d.get('tod', '')
            })
            
            if norm.replace('-', '') == normalized_seed.replace('-', ''):
                seed_hits.append({
                    'date': d['date'], 
                    'value': '-'.join(nums), 
                    'tod': d.get('tod', ''), 
                    'date_diff': (seed_date - d['date']).days
                })
    
    qualified = {}
    qualified_before = {}
    
    for cand in candidates:
        cand_norm = get_sorted_value(list(cand))
        cand_hits = all_draws_lookup.get(cand_norm.replace('-', ''), [])
        
        qualifying_after = []
        qualifying_before = []
        
        for sh in seed_hits:
            for ch in cand_hits:
                days_diff = (ch['date'] - sh['date']).days
                if 0 < days_diff <= days_threshold:
                    qualifying_after.append({
                        'seed_date': sh['date'].strftime('%Y-%m-%d'),
                        'hit_date': ch['date'].strftime('%Y-%m-%d'),
                        'value': ch['value'],
                        'days_after': days_diff
                    })
                if -days_threshold <= days_diff < 0:
                    qualifying_before.append({
                        'seed_date': sh['date'].strftime('%Y-%m-%d'),
                        'hit_date': ch['date'].strftime('%Y-%m-%d'),
                        'value': ch['value'],
                        'days_before': abs(days_diff)
                    })
        
        if qualifying_after:
            qualified[cand] = {'normalized': cand_norm, 'hit_count': len(qualifying_after), 'hits': qualifying_after[:10]}
        if qualifying_before:
            qualified_before[cand] = {'normalized': cand_norm, 'hit_count': len(qualifying_before), 'hits': qualifying_before[:10]}
    
    sorted_qual = sorted(qualified.items(), key=lambda x: x[1]['hit_count'], reverse=True)
    sorted_qual_before = sorted(qualified_before.items(), key=lambda x: x[1]['hit_count'], reverse=True)
    common_numbers = set(qualified.keys()).intersection(set(qualified_before.keys()))
    
    return jsonify({
        'algorithm': '2DP-AP',
        'db_mode': get_db_mode(),
        'seed_number': seed_number,
        'seed_date': seed_date_str,
        'normalized_seed': normalized_seed,
        'state': state,
        'game_type': game_type,
        'days_threshold': days_threshold,
        'pairs_2dp': pairs_2dp,
        'total_2dp_candidates': len(candidates),
        'seed_historical_hits': len(seed_hits),
        'seed_history': [{'date': h['date'].strftime('%Y-%m-%d'), 'value': h['value'], 'date_diff': h['date_diff']} for h in seed_hits],
        'qualified_count': len(qualified),
        'predictions': [{'number': num, **info} for num, info in sorted_qual],
        'all_numbers': sorted([num for num, _ in sorted_qual]),
        'qualified_before_count': len(qualified_before),
        'predictions_before': [{'number': num, **info} for num, info in sorted_qual_before],
        'all_numbers_before': sorted([num for num, _ in sorted_qual_before]),
        'common_count': len(common_numbers),
        'common_numbers': sorted(list(common_numbers))
    })

@app.route('/api/prediction/3dp-ap', methods=['POST'])
def predict_3dp_ap():
    """3DP-AP Prediction for Pick 5."""
    collection = get_collection()
    data = request.json
    seed_number = data.get('seed_number', data.get('seed', '')).replace('"', '').replace('[', '').replace(']', '').replace('-', '').replace(' ', '')
    seed_date_str = data.get('seed_date')
    state = data.get('state', 'California')
    days_threshold = int(data.get('days_threshold', 30))
    
    if not seed_number or not seed_date_str:
        return jsonify({'error': 'seed_number and seed_date required'}), 400
    
    if len(seed_number) != 5:
        return jsonify({'error': 'Seed number must be 5 digits for Pick 5'}), 400
    
    seed_date = datetime.strptime(seed_date_str, '%Y-%m-%d')
    normalized_seed = get_sorted_value(list(seed_number))
    
    pairs_3dp = get_3dp_pairs_pred(normalized_seed.replace('-', ''))
    candidates = generate_3dp_ap_candidates(pairs_3dp, 5)
    
    games = get_games_for_prediction(state, 'pick5')
    if not games:
        return jsonify({'error': f'No Pick 5 games found for {state}', 'db_mode': get_db_mode()}), 404
    
    query = {'state_name': state, 'game_name': {'$in': games}}
    all_draws = list(collection.find(query).sort('date', 1))
    
    seed_hits = []
    all_draws_lookup = {}
    
    for d in all_draws:
        nums = parse_numbers(d.get('numbers', '[]'))
        if len(nums) == 5:
            norm = get_sorted_value(nums)
            norm_key = norm.replace('-', '')
            if norm_key not in all_draws_lookup:
                all_draws_lookup[norm_key] = []
            all_draws_lookup[norm_key].append({
                'date': d['date'],
                'value': '-'.join(nums),
                'tod': d.get('tod', '')
            })
            
            if norm.replace('-', '') == normalized_seed.replace('-', ''):
                seed_hits.append({
                    'date': d['date'],
                    'value': '-'.join(nums),
                    'tod': d.get('tod', ''),
                    'date_diff': (seed_date - d['date']).days
                })
    
    qualified = {}
    qualified_before = {}
    
    for cand in candidates:
        cand_norm = get_sorted_value(list(cand))
        cand_hits = all_draws_lookup.get(cand_norm.replace('-', ''), [])
        
        qualifying_after = []
        qualifying_before = []
        
        for sh in seed_hits:
            for ch in cand_hits:
                days_diff = (ch['date'] - sh['date']).days
                if 0 < days_diff <= days_threshold:
                    qualifying_after.append({
                        'seed_date': sh['date'].strftime('%Y-%m-%d'),
                        'hit_date': ch['date'].strftime('%Y-%m-%d'),
                        'value': ch['value'],
                        'days_after': days_diff
                    })
                elif -days_threshold <= days_diff < 0:
                    qualifying_before.append({
                        'seed_date': sh['date'].strftime('%Y-%m-%d'),
                        'hit_date': ch['date'].strftime('%Y-%m-%d'),
                        'value': ch['value'],
                        'days_before': abs(days_diff)
                    })
        
        if qualifying_after:
            qualified[cand] = {'normalized': cand_norm, 'hit_count': len(qualifying_after), 'hits': qualifying_after[:10]}
        if qualifying_before:
            qualified_before[cand] = {'normalized': cand_norm, 'hit_count': len(qualifying_before), 'hits': qualifying_before[:10]}
    
    sorted_qual = sorted(qualified.items(), key=lambda x: x[1]['hit_count'], reverse=True)
    sorted_qual_before = sorted(qualified_before.items(), key=lambda x: x[1]['hit_count'], reverse=True)
    common_numbers = set(qualified.keys()).intersection(set(qualified_before.keys()))
    
    return jsonify({
        'algorithm': '3DP-AP',
        'db_mode': get_db_mode(),
        'seed_number': seed_number,
        'seed_date': seed_date_str,
        'normalized_seed': normalized_seed,
        'state': state,
        'game_type': 'pick5',
        'days_threshold': days_threshold,
        'pairs_3dp': pairs_3dp,
        'total_3dp_candidates': len(candidates),
        'seed_historical_hits': len(seed_hits),
        'seed_history': [{'date': h['date'].strftime('%Y-%m-%d'), 'value': h['value'], 'date_diff': h['date_diff']} for h in seed_hits],
        'qualified_count': len(qualified),
        'predictions': [{'number': num, **info} for num, info in sorted_qual],
        'all_numbers': sorted([num for num, _ in sorted_qual]),
        'qualified_before_count': len(qualified_before),
        'predictions_before': [{'number': num, **info} for num, info in sorted_qual_before],
        'all_numbers_before': sorted([num for num, _ in sorted_qual_before]),
        'common_count': len(common_numbers),
        'common_numbers': sorted(list(common_numbers))
    })

@app.route('/predictions')
def predictions_page():
    return render_template('predictions_unified.html')

@app.route('/predictions/pick5')
def predictions_pick5_page():
    return render_template('predictions_unified.html')

@app.route('/predictions/unified')
def predictions_unified_page():
    return render_template('predictions_unified.html')


# =============================================================================
# UNIFIED DP-AP PREDICTION ENDPOINT
# =============================================================================

@app.route('/api/prediction/unified-dp-ap', methods=['POST'])
def unified_dp_ap_prediction():
    """
    Unified DP-AP (Digit Pair - All Possibles) Prediction Algorithm.
    
    Supports Pick2-Pick5 with configurable pair sizes:
    - Pick2: 1DP
    - Pick3: 1DP, 2DP
    - Pick4: 1DP, 2DP, 3DP
    - Pick5: 1DP, 2DP, 3DP, 4DP
    """
    collection = get_collection()
    data = request.json
    
    state = data.get('state', 'Florida')
    game_type = data.get('game_type', 'pick4').lower()
    seed_number = data.get('seed_number', '')
    seed_date = data.get('seed_date', datetime.now().strftime('%Y-%m-%d'))
    pair_size = int(data.get('pair_size', 2))
    days_threshold = int(data.get('days_threshold', 30))
    min_hits = int(data.get('min_hits', 2))
    
    # Game configuration
    game_config = {
        'pick2': {'digits': 2, 'valid_pairs': [1]},
        'pick3': {'digits': 3, 'valid_pairs': [1, 2]},
        'pick4': {'digits': 4, 'valid_pairs': [1, 2, 3]},
        'pick5': {'digits': 5, 'valid_pairs': [1, 2, 3, 4]},
    }
    
    config = game_config.get(game_type)
    if not config:
        return jsonify({'error': f'Invalid game type: {game_type}'}), 400
    
    num_digits = config['digits']
    
    # Validate pair size
    if pair_size not in config['valid_pairs']:
        pair_size = config['valid_pairs'][-1]  # Use largest valid pair
    
    # Validate seed number
    seed_number = seed_number.replace('-', '').replace(' ', '')
    if len(seed_number) != num_digits:
        return jsonify({'error': f'Seed must be {num_digits} digits for {game_type}'}), 400
    
    # Get games for this state
    games = get_games_for_prediction(state, game_type)
    if not games:
        return jsonify({'error': f'No {game_type} games found for {state}', 'db_mode': get_db_mode()}), 404
    
    # Fetch all draws
    query = {'state_name': state, 'game_name': {'$in': games}}
    all_draws = list(collection.find(query).sort('date', 1))
    
    # Parse seed date
    try:
        seed_dt = datetime.strptime(seed_date, '%Y-%m-%d')
    except:
        seed_dt = datetime.now()
    
    # Normalize seed
    seed_norm = get_sorted_value(list(seed_number)).replace('-', '')
    
    # Get digit pairs using unified function
    pairs = get_dp_pairs(seed_number, pair_size)
    
    # Generate candidates
    candidates = generate_dp_candidates(pairs, num_digits)
    
    # Build draws index by normalized value
    draws_by_norm = {}
    for d in all_draws:
        nums = parse_numbers(d.get('numbers', '[]'))
        if len(nums) == num_digits:
            norm = get_sorted_value(nums).replace('-', '')
            if norm not in draws_by_norm:
                draws_by_norm[norm] = []
            draws_by_norm[norm].append({
                'date': d['date'],
                'value': '-'.join(nums),
                'tod': d.get('tod', '')
            })
    
    # Get seed history (when this normalized number hit before seed date)
    seed_history = []
    for h in draws_by_norm.get(seed_norm, []):
        if h['date'] < seed_dt:
            diff = (seed_dt - h['date']).days
            seed_history.append({
                'date': h['date'].strftime('%Y-%m-%d'),
                'value': h['value'],
                'date_diff': diff
            })
    seed_history = sorted(seed_history, key=lambda x: x['date_diff'])
    
    # Find candidates that hit AFTER seed's historical occurrences
    qualified_after = {}
    for cand in candidates:
        cand_norm = get_sorted_value(list(cand)).replace('-', '')
        cand_hits = draws_by_norm.get(cand_norm, [])
        
        for sh in seed_history:
            sh_date = datetime.strptime(sh['date'], '%Y-%m-%d')
            for ch in cand_hits:
                days_diff = (ch['date'] - sh_date).days
                if 0 < days_diff <= days_threshold:
                    if cand not in qualified_after:
                        qualified_after[cand] = {'normalized': cand_norm, 'hit_count': 0, 'hits': []}
                    qualified_after[cand]['hit_count'] += 1
                    qualified_after[cand]['hits'].append({
                        'date': ch['date'].strftime('%Y-%m-%d'),
                        'value': ch['value'],
                        'days_after': days_diff
                    })
    
    # Find candidates that hit BEFORE seed's historical occurrences
    qualified_before = {}
    for cand in candidates:
        cand_norm = get_sorted_value(list(cand)).replace('-', '')
        cand_hits = draws_by_norm.get(cand_norm, [])
        
        for sh in seed_history:
            sh_date = datetime.strptime(sh['date'], '%Y-%m-%d')
            for ch in cand_hits:
                days_diff = (ch['date'] - sh_date).days
                if -days_threshold <= days_diff < 0:
                    if cand not in qualified_before:
                        qualified_before[cand] = {'normalized': cand_norm, 'hit_count': 0, 'hits': []}
                    qualified_before[cand]['hit_count'] += 1
                    qualified_before[cand]['hits'].append({
                        'date': ch['date'].strftime('%Y-%m-%d'),
                        'value': ch['value'],
                        'days_before': abs(days_diff)
                    })
    
    # Filter by min hits
    qualified_after = {k: v for k, v in qualified_after.items() if v['hit_count'] >= min_hits}
    qualified_before = {k: v for k, v in qualified_before.items() if v['hit_count'] >= min_hits}
    
    # Find common (in both after and before)
    common_numbers = sorted(set(qualified_after.keys()) & set(qualified_before.keys()))
    
    # Sort by hit count
    sorted_after = sorted(qualified_after.items(), key=lambda x: x[1]['hit_count'], reverse=True)
    sorted_before = sorted(qualified_before.items(), key=lambda x: x[1]['hit_count'], reverse=True)
    
    return jsonify({
        'state': state,
        'game_type': game_type,
        'seed_number': seed_number,
        'seed_date': seed_date,
        'normalized_seed': seed_norm,
        'pair_size': pair_size,
        'pairs': pairs,
        'total_candidates': len(candidates),
        'seed_historical_hits': len(seed_history),
        'seed_history': seed_history[:20],
        'qualified_count': len(qualified_after),
        'qualified_before_count': len(qualified_before),
        'common_count': len(common_numbers),
        'common_numbers': common_numbers,
        'predictions': [{'number': num, **info} for num, info in sorted_after[:50]],
        'predictions_before': [{'number': num, **info} for num, info in sorted_before[:50]],
        'all_numbers': sorted(qualified_after.keys()),
        'all_numbers_before': sorted(qualified_before.keys()),
        'db_mode': get_db_mode()
    })


# =============================================================================
# PICK5 SPECIFIC API ROUTES
# =============================================================================

@app.route('/api/prediction/pick5/states')
def get_prediction_pick5_states():
    """Get states that have Pick 5 games."""
    collection = get_collection()
    all_states = collection.distinct('state_name')
    
    # Filter to states that have pick5 games
    pick5_states = []
    for state in all_states:
        if not state:
            continue
        games = collection.distinct('game_name', {'state_name': state})
        for g in games:
            gl = g.lower()
            if any(x in gl for x in ['pick 5', 'pick5', 'daily 5', 'daily5', 'cash 5', 'cash5']):
                pick5_states.append(state)
                break
    
    return jsonify(sorted(pick5_states))

@app.route('/api/prediction/pick5/games/<state>')
def get_prediction_pick5_games(state):
    """Get Pick 5 games for a state."""
    collection = get_collection()
    games = collection.distinct('game_name', {'state_name': state})
    
    pick5_games = []
    for g in games:
        gl = g.lower()
        if any(x in gl for x in ['pick 5', 'pick5', 'daily 5', 'daily5', 'cash 5', 'cash5']):
            pick5_games.append({'id': g, 'name': g})
    
    return jsonify(pick5_games)

@app.route('/api/prediction/pick5/latest/<state>')
def get_latest_pick5_draw(state):
    """Get the latest Pick 5 draw for a state."""
    collection = get_collection()
    games = get_games_for_prediction(state, 'pick5')
    if not games:
        return jsonify({'error': 'No pick5 games found', 'db_mode': get_db_mode()}), 404
    
    query = {'state_name': state, 'game_name': {'$in': games}}
    latest = collection.find_one(query, sort=[('date', -1)])
    
    if latest:
        nums = parse_numbers(latest.get('numbers', '[]'))
        return jsonify({
            'date': latest['date'].strftime('%Y-%m-%d'),
            'value': '-'.join(nums),
            'normalized': get_sorted_value(nums),
            'game': latest['game_name'],
            'tod': latest.get('tod', ''),
            'db_mode': get_db_mode()
        })
    return jsonify({'error': 'No draws found', 'db_mode': get_db_mode()}), 404

@app.route('/api/prediction/pick5/draw-by-date/<state>/<draw_date>')
def get_pick5_draw_by_date(state, draw_date):
    """Get Pick 5 draw for a specific date."""
    collection = get_collection()
    games = get_games_for_prediction(state, 'pick5')
    if not games:
        return jsonify({'error': 'No pick5 games found', 'db_mode': get_db_mode()}), 404
    
    try:
        date_obj = datetime.strptime(draw_date, '%Y-%m-%d')
    except:
        return jsonify({'error': 'Invalid date format'}), 400
    
    query = {
        'state_name': state,
        'game_name': {'$in': games},
        'date': {'$gte': date_obj, '$lt': date_obj + timedelta(days=1)}
    }
    
    tod = request.args.get('tod', '')
    draws = list(collection.find(query))
    
    if not draws:
        return jsonify({'error': f'No draw found for {draw_date}', 'db_mode': get_db_mode()}), 404
    
    if tod:
        filtered = [d for d in draws if d.get('tod', '').lower() == tod.lower()]
        if filtered:
            draws = filtered
    
    draw = draws[0]
    nums = parse_numbers(draw.get('numbers', '[]'))
    
    return jsonify({
        'date': draw['date'].strftime('%Y-%m-%d'),
        'value': '-'.join(nums),
        'normalized': get_sorted_value(nums),
        'game': draw['game_name'],
        'tod': draw.get('tod', ''),
        'db_mode': get_db_mode()
    })



# =============================================================================
# EFFICACY REPORT ROUTES
# =============================================================================

@app.route('/report/efficacy')
def efficacy_report_page():
    return render_template('efficacy_report_unified.html')

@app.route('/report/efficacy-unified')
def efficacy_report_unified_page():
    return render_template('efficacy_report_unified.html')

@app.route('/report/efficacy-pick5')
def efficacy_report_pick5_page():
    return render_template('efficacy_report_unified.html')


# =============================================================================
# QUERY COST ESTIMATION & BACKGROUND JOBS API
# =============================================================================

@app.route('/api/query/estimate-cost', methods=['POST'])
def estimate_cost_endpoint():
    """
    Estimate the cost and time for a query before running it.
    Returns whether the query is heavy/chargeable and offers options.
    """
    data = request.json
    query_type = data.get('query_type', 'efficacy_report')
    params = data.get('params', {})
    
    estimate = estimate_query_cost(query_type, params)
    
    if estimate['is_heavy'] or estimate['is_chargeable']:
        return jsonify({
            'requires_confirmation': True,
            'estimate': estimate,
            'message': _build_cost_message(estimate),
            'options': [
                {'action': 'cancel', 'label': 'Cancel', 'icon': '❌'},
                {'action': 'background', 'label': 'Run in Background', 'icon': '📧', 'requires_email': True},
                {'action': 'proceed', 'label': f"Run Now{' ($' + str(estimate['estimated_cost']) + ')' if estimate['is_chargeable'] else ''}", 'icon': '▶️'}
            ]
        })
    
    return jsonify({
        'requires_confirmation': False,
        'estimate': estimate,
        'message': 'Query is within free tier limits'
    })


@app.route('/api/query/background-job', methods=['POST'])
def create_background_job_endpoint():
    """
    Create a background job for a heavy query.
    User will be notified by email when complete.
    """
    data = request.json
    job_type = data.get('job_type', 'efficacy_report')
    params = data.get('params', {})
    user_email = data.get('email', '')
    
    if not user_email or '@' not in user_email:
        return jsonify({'error': 'Valid email required for background jobs'}), 400
    
    job_id = create_background_job(job_type, params, user_email)
    
    # In production, this would queue the job to Celery/Redis
    # For now, just acknowledge the request
    
    return jsonify({
        'success': True,
        'job_id': job_id,
        'status': 'queued',
        'message': f'Job queued. Results will be sent to {user_email} when complete.',
        'estimated_time': estimate_query_cost(job_type, params).get('estimated_time_seconds', 30)
    })


@app.route('/api/query/job-status/<job_id>')
def get_job_status_endpoint(job_id):
    """Get the status of a background job."""
    job = get_job_status(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify(job)


@app.route('/api/query/charge', methods=['POST'])
def charge_for_query():
    """
    Process payment for a chargeable query.
    In production, this would integrate with Stripe.
    """
    data = request.json
    amount = data.get('amount', 0)
    query_type = data.get('query_type', '')
    user_id = data.get('user_id', 'anonymous')
    
    # Mock charge - in production use Stripe
    charge_id = hashlib.md5(f"{user_id}{amount}{datetime.now().isoformat()}".encode()).hexdigest()[:10]
    
    return jsonify({
        'success': True,
        'charge_id': f'ch_{charge_id}',
        'amount': amount,
        'message': f'Charged ${amount:.4f} for {query_type}'
    })


def _build_cost_message(estimate):
    """Build a human-readable message about query cost."""
    parts = []
    
    if estimate['estimated_time_seconds'] > 15:
        parts.append(f"⏱️ This query may take ~{int(estimate['estimated_time_seconds'])} seconds.")
    
    if estimate['is_chargeable']:
        parts.append(f"💰 Cost: ${estimate['estimated_cost']:.4f}")
    
    if estimate.get('warnings'):
        parts.append("⚠️ " + " | ".join(estimate['warnings']))
    
    if estimate['recommendation'] == 'background':
        parts.append("💡 We recommend running this in the background.")
    
    return " ".join(parts) if parts else "Query ready to run."

@app.route('/api/prediction/efficacy-report', methods=['POST'])
def efficacy_report():
    """
    Unified DP AP (Digit Pair - All Possibles) Efficacy Report
    
    Supports Pick2 through Pick5 with dynamic pair sizes:
    - Pick2: 1DP
    - Pick3: 1DP, 2DP
    - Pick4: 1DP, 2DP, 3DP
    - Pick5: 1DP, 2DP, 3DP, 4DP
    
    Rule: pair_size must be < num_digits
    """
    collection = get_collection()
    data = request.json
    state = data.get('state', 'California')
    start_date = datetime.strptime(data.get('start_date', '2026-01-01'), '%Y-%m-%d')
    end_date = datetime.strptime(data.get('end_date', '2026-01-31'), '%Y-%m-%d')
    days_threshold = int(data.get('days_threshold', 30))
    hit_window = int(data.get('hit_window', 10))
    game_type = data.get('game_type', 'pick4').lower()
    pair_size = int(data.get('pair_size', 0))  # 0 means use default
    
    # Unified game configuration for Pick2-Pick5
    # Valid pairs: 1 to (digits-1) - you can't match the whole number
    game_config = {
        'pick2': {'digits': 2, 'valid_pairs': [1], 'default_pair': 1},
        'pick3': {'digits': 3, 'valid_pairs': [1, 2], 'default_pair': 2},
        'pick4': {'digits': 4, 'valid_pairs': [1, 2, 3], 'default_pair': 2},
        'pick5': {'digits': 5, 'valid_pairs': [1, 2, 3, 4], 'default_pair': 3},
    }
    
    config = game_config.get(game_type)
    if not config:
        return jsonify({'error': f'Invalid game type: {game_type}. Supported: pick2, pick3, pick4, pick5', 'db_mode': get_db_mode()}), 400
    
    num_digits = config['digits']
    
    # Use default pair size if not specified or invalid
    if pair_size not in config['valid_pairs']:
        pair_size = config['default_pair']
    
    games = get_games_for_prediction(state, game_type)
    if not games:
        return jsonify({'error': f'No {game_type} games found for {state}', 'db_mode': get_db_mode()}), 404
    
    query = {'state_name': state, 'game_name': {'$in': games}}
    all_draws = list(collection.find(query).sort('date', 1))
    
    # Build draws index by normalized value
    draws_by_norm = {}
    for d in all_draws:
        nums = parse_numbers(d.get('numbers', '[]'))
        if len(nums) == num_digits:
            norm = get_sorted_value(nums).replace('-', '')
            if norm not in draws_by_norm:
                draws_by_norm[norm] = []
            draws_by_norm[norm].append({
                'date': d['date'],
                'value': '-'.join(nums),
                'tod': d.get('tod', '')
            })
    
    # Get seeds in date range
    seeds_in_range = [d for d in all_draws 
                      if start_date <= d['date'] <= end_date 
                      and len(parse_numbers(d.get('numbers', '[]'))) == num_digits]
    
    results = []
    total_common = 0
    total_hits_within_window = 0
    
    for seed_draw in seeds_in_range:
        seed_nums = parse_numbers(seed_draw.get('numbers', '[]'))
        seed_norm = get_sorted_value(seed_nums).replace('-', '')
        seed_date = seed_draw['date']
        seed_value = '-'.join(seed_nums)
        
        # Get pairs using unified function
        pairs = get_dp_pairs(seed_norm, pair_size)
        candidates = generate_dp_candidates(pairs, num_digits)
        
        seed_history = [h for h in draws_by_norm.get(seed_norm, []) if h['date'] < seed_date]
        
        if not seed_history:
            continue
        
        # Find candidates that hit AFTER seed's historical hits
        qualified_after = set()
        for cand in candidates:
            cand_norm = get_sorted_value(list(cand)).replace('-', '')
            cand_hits = draws_by_norm.get(cand_norm, [])
            for sh in seed_history:
                for ch in cand_hits:
                    days_diff = (ch['date'] - sh['date']).days
                    if 0 < days_diff <= days_threshold:
                        qualified_after.add(cand)
                        break
        
        # Find candidates that hit BEFORE seed's historical hits
        qualified_before = set()
        for cand in candidates:
            cand_norm = get_sorted_value(list(cand)).replace('-', '')
            cand_hits = draws_by_norm.get(cand_norm, [])
            for sh in seed_history:
                for ch in cand_hits:
                    days_diff = (ch['date'] - sh['date']).days
                    if -days_threshold <= days_diff < 0:
                        qualified_before.add(cand)
                        break
        
        # Common candidates (hit both before AND after seed historically)
        common = qualified_after.intersection(qualified_before)
        
        if not common:
            continue
        
        # Check if common candidates actually hit within window of current seed
        hits_within_window = []
        for num in common:
            num_norm = get_sorted_value(list(num)).replace('-', '')
            num_hits = draws_by_norm.get(num_norm, [])
            for h in num_hits:
                days_diff = (h['date'] - seed_date).days
                if -hit_window <= days_diff <= hit_window and days_diff != 0:
                    hits_within_window.append({
                        'number': num,
                        'hit_date': h['date'].strftime('%Y-%m-%d'),
                        'hit_value': h['value'],
                        'days_from_seed': days_diff,
                        'direction': 'AFTER' if days_diff > 0 else 'BEFORE'
                    })
                    break
        
        total_common += len(common)
        total_hits_within_window += len(hits_within_window)
        
        results.append({
            'seed_date': seed_date.strftime('%Y-%m-%d'),
            'seed_value': seed_value,
            'seed_norm': seed_norm,
            'pairs': pairs,
            'common_count': len(common),
            'hits_within_window': len(hits_within_window),
            'hit_rate': round(len(hits_within_window) / len(common) * 100, 1) if common else 0,
            'hits_detail': hits_within_window
        })
    
    overall_rate = round(total_hits_within_window / total_common * 100, 1) if total_common > 0 else 0
    
    # Algorithm name based on pair size
    algo_name = f'{pair_size}DP-AP'
    
    return jsonify({
        'state': state,
        'game_type': game_type,
        'algorithm': algo_name,
        'pair_size': pair_size,
        'num_digits': num_digits,
        'valid_pair_sizes': config['valid_pairs'],
        'db_mode': get_db_mode(),
        'date_range': f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
        'days_threshold': days_threshold,
        'hit_window': hit_window,
        'total_seeds_analyzed': len(results),
        'total_common_predicted': total_common,
        'total_hits_within_window': total_hits_within_window,
        'overall_hit_rate': overall_rate,
        'results': results
    })


@app.route('/api/prediction/dp-options/<game_type>')
def get_dp_options(game_type):
    """
    Get available digit pair options for a game type.
    
    Unified for Pick2-Pick5:
    - Pick2: 1DP only
    - Pick3: 1DP, 2DP
    - Pick4: 1DP, 2DP, 3DP
    - Pick5: 1DP, 2DP, 3DP, 4DP
    
    Rule: pair_size must be < num_digits
    """
    # Define options with descriptions and candidate counts
    dp_descriptions = {
        1: {'label': '1DP - Single Digits', 'desc': 'Match any single digit', 'coverage': 'High'},
        2: {'label': '2DP - 2-Digit Pairs', 'desc': 'Match pairs of 2 digits', 'coverage': 'Medium'},
        3: {'label': '3DP - 3-Digit Pairs', 'desc': 'Match pairs of 3 digits', 'coverage': 'Low'},
        4: {'label': '4DP - 4-Digit Pairs', 'desc': 'Match pairs of 4 digits', 'coverage': 'Very Low'},
    }
    
    # Estimated candidate counts for each game/pair combo
    candidate_estimates = {
        'pick2': {1: 10},
        'pick3': {1: 220, 2: 55},
        'pick4': {1: 715, 2: 330, 3: 120},
        'pick5': {1: 2002, 2: 715, 3: 252, 4: 126},
    }
    
    # Default pair sizes (balanced between coverage and precision)
    defaults = {
        'pick2': 1,
        'pick3': 2,
        'pick4': 2,
        'pick5': 3,
    }
    
    game = game_type.lower()
    
    # Get number of digits for this game
    num_digits = {'pick2': 2, 'pick3': 3, 'pick4': 4, 'pick5': 5}.get(game)
    
    if not num_digits:
        return jsonify({'error': f'Invalid game type: {game_type}. Supported: pick2, pick3, pick4, pick5'}), 400
    
    # Valid pairs are 1 to (digits-1)
    valid_pairs = list(range(1, num_digits))
    
    options = []
    for size in valid_pairs:
        info = dp_descriptions.get(size, {})
        est_candidates = candidate_estimates.get(game, {}).get(size, 'N/A')
        options.append({
            'size': size,
            'label': info.get('label', f'{size}DP'),
            'description': info.get('desc', f'Match {size}-digit combinations'),
            'coverage': info.get('coverage', 'Unknown'),
            'estimated_candidates': est_candidates
        })
    
    return jsonify({
        'game_type': game,
        'num_digits': num_digits,
        'options': options,
        'default': defaults.get(game, valid_pairs[-1])
    })

@app.route('/api/prediction/efficacy-report-all-states', methods=['POST'])
def efficacy_report_all_states():
    """Generate efficacy report across all states"""
    return efficacy_report()

# =============================================================================
# CONSECUTIVE DRAWS ALGORITHM
# =============================================================================

@app.route('/consecutive')
def consecutive_draws_page():
    """Page for Consecutive Draws algorithm."""
    return render_template('consecutive_draws.html')

@app.route('/api/consecutive/states')
def get_consecutive_states():
    """Get all states for consecutive draws - only states with true Pick5 games."""
    game_type = request.args.get('game_type', 'pick5')
    
    # States with TRUE Pick5 games (5-digit daily games)
    PICK5_STATES = [
        'Maryland', 'Florida', 'Virginia', 'Delaware', 'Ohio', 
        'Pennsylvania', 'Georgia', 'Washington DC', 'Louisiana', 'Germany'
    ]
    
    # States with Pick4 games - get from database
    PICK4_STATES = None  # Will query all states for pick4
    
    if game_type == 'pick5':
        return jsonify(sorted(PICK5_STATES))
    else:
        # For pick4, get all states from database
        collection = get_collection()
        states = collection.distinct('state_name')
        return jsonify(sorted([s for s in states if s]))

@app.route('/api/consecutive/debug-games/<state>')
def debug_games_for_state(state):
    """Debug endpoint to see what games are available for a state."""
    collection = get_collection()
    all_games = collection.distinct('game_name', {'state_name': state})
    
    pick4_games = get_games_for_prediction(state, 'pick4')
    pick5_games = get_games_for_prediction(state, 'pick5')
    
    # Get sample draws for each game
    samples = {}
    for game in all_games[:20]:  # Limit to 20 games
        sample = collection.find_one({'state_name': state, 'game_name': game})
        if sample:
            nums = parse_numbers(sample.get('numbers', '[]'))
            samples[game] = {
                'num_digits': len(nums),
                'sample_numbers': nums,
                'sample_date': sample['date'].strftime('%Y-%m-%d') if sample.get('date') else None
            }
    
    return jsonify({
        'state': state,
        'all_games': sorted(all_games),
        'matched_pick4': pick4_games,
        'matched_pick5': pick5_games,
        'game_samples': samples,
        'db_mode': get_db_mode()
    })

@app.route('/api/consecutive/email-report', methods=['POST'])
def request_email_report():
    """
    Queue a report to be emailed to the user.
    In production, this would add to a job queue (Celery, etc.)
    """
    data = request.json
    email = data.get('email')
    
    if not email or '@' not in email:
        return jsonify({'error': 'Valid email required'}), 400
    
    # In production, you would:
    # 1. Add this to a background job queue (Celery, RQ, etc.)
    # 2. Process the query asynchronously
    # 3. Email the results when complete
    
    # For now, just acknowledge the request
    return jsonify({
        'success': True,
        'message': f'Report will be sent to {email}',
        'query_params': {
            'game_type': data.get('game_type'),
            'states': data.get('states'),
            'start_date': data.get('start_date'),
            'end_date': data.get('end_date'),
            'tod': data.get('tod')
        }
    })

@app.route('/api/consecutive/draws', methods=['POST'])
def get_consecutive_draws():
    """
    Step 1: Get all winning numbers in date range and their historical permutations.
    
    Input:
    - game_type: pick4 or pick5
    - states: list of states or ['All']
    - start_date: YYYY-MM-DD
    - end_date: YYYY-MM-DD
    - tod: All, Midday, Evening, Day, Night (optional)
    
    Output:
    - past_winners: list of unique normalized numbers from date range
    - draws: list of all historical occurrences with full details
    """
    collection = get_collection()
    data = request.json
    
    game_type = data.get('game_type', 'pick5')
    states = data.get('states', ['All'])
    start_date = datetime.strptime(data.get('start_date', '2026-01-01'), '%Y-%m-%d')
    end_date = datetime.strptime(data.get('end_date', '2026-01-01'), '%Y-%m-%d')
    tod_filter = data.get('tod', 'All')
    
    num_digits = 5 if game_type == 'pick5' else 4
    
    # States with TRUE Pick5 games only
    PICK5_STATES = [
        'Maryland', 'Florida', 'Virginia', 'Delaware', 'Ohio', 
        'Pennsylvania', 'Georgia', 'Washington DC', 'Louisiana', 'Germany'
    ]
    
    # Filter states based on game type
    if game_type == 'pick5':
        if 'All' in states or not states:
            allowed_states = PICK5_STATES
        else:
            # Only allow states that are in the approved list
            allowed_states = [s for s in states if s in PICK5_STATES]
    else:
        # For pick4, allow all states
        if 'All' in states or not states:
            allowed_states = collection.distinct('state_name')
        else:
            allowed_states = states
    
    # Get games for this game type - only from allowed states
    games_by_state = {}
    for state in allowed_states:
        if not state:
            continue
        games = get_games_for_prediction(state, game_type)
        if games:
            games_by_state[state] = games
    
    if not games_by_state:
        return jsonify({'error': f'No {game_type} games found', 'db_mode': get_db_mode()}), 404
    
    # Step 1: Get all draws in the user's selected date range (seed draws)
    seed_draws = []
    seen_seeds = set()  # Track unique seed draws
    
    for state, games in games_by_state.items():
        query = {
            'state_name': state,
            'game_name': {'$in': games},
            'date': {'$gte': start_date, '$lt': end_date + timedelta(days=1)}
        }
        draws = list(collection.find(query))
        for d in draws:
            nums = parse_numbers(d.get('numbers', '[]'))
            if len(nums) == num_digits:
                tod = d.get('tod', '')
                if tod_filter != 'All' and tod.lower() != tod_filter.lower():
                    continue
                
                # Create unique key to prevent duplicates
                seed_key = (d['date'].strftime('%Y-%m-%d'), state, ''.join(nums), tod)
                if seed_key in seen_seeds:
                    continue
                seen_seeds.add(seed_key)
                
                seed_draws.append({
                    'date': d['date'],
                    'value': ''.join(nums),
                    'normalized': get_sorted_value(nums).replace('-', ''),
                    'state': d.get('state_name', ''),
                    'tod': tod,
                    'game': d.get('game_name', ''),
                    'digits_sum': sum(int(n) for n in nums)
                })
    
    if not seed_draws:
        return jsonify({
            'error': 'No draws found in selected date range',
            'db_mode': get_db_mode()
        }), 404
    
    # Get unique normalized numbers from seed draws
    seed_by_norm = {}
    for sd in seed_draws:
        norm = sd['normalized']
        if norm not in seed_by_norm:
            seed_by_norm[norm] = []
        seed_by_norm[norm].append(sd)
    
    past_winners = list(seed_by_norm.keys())
    
    # Step 2: For each seed normalized number, find ALL historical occurrences
    all_historical = []
    
    # Build a lookup of all draws by normalized value for efficiency
    all_draws_query = {}
    all_state_games = []
    for state, games in games_by_state.items():
        for game in games:
            all_state_games.append({'state_name': state, 'game_name': game})
    
    if all_state_games:
        all_draws_query['$or'] = all_state_games
    
    all_draws = list(collection.find(all_draws_query).sort('date', 1))
    
    # Index by normalized value - deduplicate by date+state+value
    draws_by_norm = {}
    seen_draws = set()  # Track unique draws to prevent duplicates
    
    for d in all_draws:
        nums = parse_numbers(d.get('numbers', '[]'))
        if len(nums) != num_digits:
            continue
        
        # Create unique key to prevent duplicates
        draw_key = (d['date'].strftime('%Y-%m-%d'), d.get('state_name', ''), ''.join(nums), d.get('tod', ''))
        if draw_key in seen_draws:
            continue
        seen_draws.add(draw_key)
        
        norm = get_sorted_value(nums).replace('-', '')
        if norm not in draws_by_norm:
            draws_by_norm[norm] = []
        draws_by_norm[norm].append({
            'date': d['date'],
            'value': ''.join(nums),
            'normalized': norm,
            'state': d.get('state_name', ''),
            'tod': d.get('tod', ''),
            'game': d.get('game_name', ''),
            'digits_sum': sum(int(n) for n in nums)
        })
    
    # Count total times drawn for each normalized number
    times_drawn = {norm: len(draws) for norm, draws in draws_by_norm.items()}
    
    # Build the results table
    results = []
    for norm, seed_list in seed_by_norm.items():
        historical_draws = draws_by_norm.get(norm, [])
        hit_count = len(historical_draws)
        
        for hist in historical_draws:
            # For each seed draw that matches this norm
            for seed in seed_list:
                date_diff = (seed['date'] - hist['date']).days
                
                # Calculate delta sums
                delta_sums = abs(seed['digits_sum'] - hist['digits_sum'])
                
                results.append({
                    'date': hist['date'].strftime('%Y-%m-%d'),
                    'value': hist['value'],
                    'norm': hist['normalized'],
                    'state': hist['state'],
                    'tod': hist['tod'],
                    'group': hist['date'].month,
                    'hit_count': hit_count,
                    'hit_ratio': round(hit_count / max(times_drawn.get(norm, 1), 1) * 100) if times_drawn else 0,
                    'repeat': len([h for h in historical_draws if h['value'] == hist['value']]),
                    'month': hist['date'].strftime('%Y-%m'),
                    'input_date': seed['date'].strftime('%Y-%m-%d'),
                    'perm': seed['value'],
                    'state2': seed['state'],
                    'tod2': seed['tod'],
                    'date_diff': date_diff,
                    'sums': hist['digits_sum'],
                    'td': times_drawn.get(norm, 0),
                    'delta_sums_td': delta_sums,
                    'sdt': 'D' if delta_sums <= 10 else 'S'
                })
    
    # Sort by date descending
    results.sort(key=lambda x: (x['input_date'], x['date']), reverse=True)
    
    return jsonify({
        'game_type': game_type,
        'date_range': f"{start_date.strftime('%Y-%m-%d')} - {end_date.strftime('%Y-%m-%d')}",
        'states': states,
        'past_winners': sorted(past_winners),
        'total_seed_draws': len(seed_draws),
        'total_historical_matches': len(results),
        'draws': results[:5000],  # Limit to prevent huge responses
        'db_mode': get_db_mode()
    })


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5001))
    print(f"\n{'='*60}")
    print("LOTTERY PREDICTION APP")
    print(f"{'='*60}")
    print(f"Running on: http://localhost:{port}")
    print(f"DB Mode: {DEFAULT_DB_MODE}")
    print(f"{'='*60}\n")
    app.run(debug=True, host='0.0.0.0', port=port)
